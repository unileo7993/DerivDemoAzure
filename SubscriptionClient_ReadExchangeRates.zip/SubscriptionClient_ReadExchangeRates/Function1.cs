using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace SubscriptionClient_ReadExchangeRates
{
    public class Function1
    {
        //private readonly ILogger<Function1> _logger;
        private readonly IConfiguration _configuration;
        public string strTopicName = "";
        public  string strSunscriptionName;

        public Function1(IConfiguration configuration)
        {
            //_logger = log;
            _configuration = configuration;
        }

        [FunctionName("Function1")]
        public static void Run([ServiceBusTrigger("fetchexchangeratefunction", "Server1", Connection = "ServiceBusConnection")]string mySbMsg, ILogger logger)
        {
            logger.LogInformation($"C# Timer function executed at: {DateTime.Now}");
            logger.LogInformation($"C# ServiceBus topic trigger function processed message: {mySbMsg}");
        }
    }
}
