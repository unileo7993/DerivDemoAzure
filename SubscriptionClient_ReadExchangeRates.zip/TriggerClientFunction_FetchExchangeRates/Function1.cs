using System;
using Microsoft.AspNetCore.Http;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.Azure.ServiceBus.Core;
using Microsoft.Azure.ServiceBus;
using System.Net.Http;
using Microsoft.Extensions.Configuration;
using Azure.Messaging.ServiceBus;
using System.Linq;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Collections;

namespace TriggerClientFunction_FetchExchangeRates
{
    public class Function1
    {


        private readonly IConfiguration configuration;
        public Function1(IConfiguration _configuration)
        {
            configuration = _configuration;
        }
        public async Task<string> ExchangeRates()
        {


            //// Call Your  API
            //HttpClient newClient = new HttpClient();
            //HttpRequestMessage newRequest = new HttpRequestMessage(HttpMethod.Get, string.Format(configuration.GetSection("URL_ExchangeRate").Value));

            ////Read Server Response
            //HttpResponseMessage response = await newClient.SendAsync(newRequest, HttpCompletionOption.ResponseContentRead);

            //return response.Content.ToString();
            string rates = string.Empty;
            var url = string.Format(configuration.GetSection("URL_ExchangeRate").Value);
            var parameters = string.Format(configuration.GetSection("URL_PARAM_ExchangeRate").Value);

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(url);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            HttpResponseMessage response = await client.GetAsync(parameters).ConfigureAwait(true);

            if (response.IsSuccessStatusCode)
            {
                rates =  await response.Content.ReadAsStringAsync();
            }
            return rates;
        }

        [FunctionName("Function1")]
        public async Task Run([TimerTrigger("0 */5 * * * *")] TimerInfo myTimer, ILogger log) //"0 0 */2 * * *"
        {
            log.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");

            var sbClient = new ServiceBusClient(string.Format(configuration.GetSection("ServiceBusConnection").Value));
            var sbSender = sbClient.CreateSender(string.Format(configuration.GetSection("TopicName").Value));
            var ExchangeRate = ExchangeRates().Result.ToString();
            var sbMessage = new ServiceBusMessage((ExchangeRate));
            await sbSender.SendMessageAsync(sbMessage);
        }
        //[return: ServiceBus("fetchexchangeratefunction", Connection = "ServiceBusConnection")]
        //public static async Task RunAsync([TimerTrigger("0 0 */2 * * *")] TimerInfo myTimer,
        //    //[HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
        //    //[ServiceBus("fetchexchangeratefunction", Connection = "ServiceBusConnection")] MessageSender messagesQueue,
        //    ILogger log, IConfiguration configuration)
        //{
        //    log.LogInformation("C# HTTP trigger function processed a request.");

        //    //string name = req.Query["name"];

        //    //string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
        //    //dynamic data = JsonConvert.DeserializeObject(requestBody);
        //    //name = name ?? data?.name;

        //    //string responseMessage = string.IsNullOrEmpty(name)
        //    //    ? "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response."
        //    //    : $"Hello, {name}. This HTTP triggered function executed successfully.";

        //    #region n1

        //    // Call Your  API
        //    HttpClient newClient = new HttpClient();
        //    HttpRequestMessage newRequest = new HttpRequestMessage(HttpMethod.Get, string.Format(configuration.GetSection("URL_ExchangeRate").Value));

        //    //Read Server Response
        //    HttpResponseMessage response = await newClient.SendAsync(newRequest);
        //    //string responseMessage = JsonConvert.DeserializeObject(response);
        //    bool isValidMpn = await response.Content.ReadAsAsync<bool>();

        //    #endregion


        //    byte[] bytes = Encoding.ASCII.GetBytes("test");
        //    Message m1 = new Message(bytes);
        //    await messagesQueue.SendAsync(m1);

        //}
    }
}
